#include <cstddef>
int main(int argc, char* argv[])
{
    int* p = nullptr;
    return 0;
}
